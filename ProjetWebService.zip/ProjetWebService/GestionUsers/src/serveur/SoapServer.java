package serveur;

import javax.xml.ws.Endpoint;
import service.ManageUsers;

public class SoapServer
{
	public static void main(String[] args)
	{
		String url = "http://localhost:8585/";
		Endpoint.publish(url, new ManageUsers());
		System.out.println("Serveur a l'ecoute a l'adresse : " + url);
	}
}