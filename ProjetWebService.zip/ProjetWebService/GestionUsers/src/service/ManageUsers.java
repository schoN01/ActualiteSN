package service;

import java.util.ArrayList;
import java.util.Scanner;

import javax.jws.WebParam;
import javax.jws.WebService;

@WebService
public class ManageUsers {
	
	   static ArrayList<UserSite> ListeUsers = new ArrayList<UserSite>();
	   
	 /*Saisie action	
	 		Scanner sc = new Scanner(System.in);
	 		String str = sc.nextLine();	

	/*   public void Authentification() 
	    {
		   System.out.println("Veuillez entrer votre login");
		   String login = sc.next();
		   System.out.println("Veuillez entrer votre mot de passe");
		   String password = sc.next();
		   
	    }*/

	   public String Ajouter(@WebParam(name="login") String login,@WebParam(name="motdepasse") String password, 
			   @WebParam(name="email") String email, @WebParam(name="typeUser") String userType )
	    {
	    UserSite e = new UserSite(login, password, email, userType);
	    ListeUsers.add(e);

	        return "Ajout effectu� avec succ�s (ID =" + e.getId() + ")";
	    }

	    public String Modifier(@WebParam(name="id") int id, @WebParam(name="login") String login,@WebParam(name="motdepasse") String password,
	    		@WebParam(name="email") String email, @WebParam(name="typeUser") String userType )
	    {
	        for (UserSite user : ListeUsers) {
	            if(user.getId()==id){
	            	user.setLogin(login);
	            	user.setPassword(password);
	            	user.setEmail(email);
	            	user.setUserType(userType);
	            	
	                return "Mise � jour effectu�e avec succ�s";
	            } 
	        }
	        return "Aucune Mise � jour effectu�e";
	    }

	    public String Supprimer(@WebParam(name="id") int id, @WebParam(name="login") String login,@WebParam(name="motdepasse") String password,
	    		@WebParam(name="email") String email, @WebParam(name="typeUser") String userType)
	    {
	        for (UserSite user : ListeUsers) {
	            if(user.getId()==id){
	            	ListeUsers.remove(user);

	                return "Suppression effectu�e avec succ�s";
	            } 
	        }
	        return "Aucune Suppression effectu�e";
	    }

	    public static ArrayList<UserSite> Lister(){
	    	//ArrayList<UserSite> ListeUsers=new ArrayList<UserSite>(); 
	        return ListeUsers;
	    }

	    public static void main(String[] args) {
	    	ManageUsers e1 = new ManageUsers();
	    	ManageUsers e2 = new ManageUsers();
	        e1.Ajouter("Katambu", "Rebecca","reb@gmail.com","Editeur");
	        e2.Ajouter("Nkongolo", "Schola","scho@gmail.com","Administrateur");
	        
	        System.out.println("voici la liste des �tudiants : " + Lister());
	    }
	
	
	
	

}
