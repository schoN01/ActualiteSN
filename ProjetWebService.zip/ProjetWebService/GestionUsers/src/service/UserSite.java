package service;

//import java.time.LocalDate;

public class UserSite {
	//private string dateCreation,dateMaj
	private int id;
    private String login, password, email,userType;
    
    private static int lastId = 1;

    public UserSite(){}

    public UserSite(String login, String password,String email, String userType)
    {
        this.id = lastId++;
        this.login = login;
        this.password = password;
        this.email = email;
        this.userType = userType;           		
    }

	public int getId() {
		return this.id ;
	}

	public String setLogin(String login) {
		return this.login;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public String setEmail(String email) {
		return	this.email;
	}

	public String setUserType(String userType) {
		return this.userType = userType;
	}

	public String toString(){
	    return "(login : " + this.login + " et Type d'utilisateur: " + this.userType +")";
	 }
   
}
